const express = require('express'); 

const bodyParser = require('body-parser'); 

const createCsvWriter = require('csv-writer').createObjectCsvWriter; 

 

const app = express(); 

const port = 3000; 

 

// Middleware 

app.use(bodyParser.urlencoded({ extended: false })); 

app.use(bodyParser.json()); 

    

// CSV Writer 

const csvWriter = createCsvWriter({ 

    path: 'form-data.csv', 

    header: [ 

        {id: 'name', title: 'Name'}, 

        {id: 'email', title: 'Email'}, 
		
		{id: 'phone', title: 'phone'},

        {id: 'message', title: 'Message'}, 

        {id: 'query', title: 'Query'} 

    ], 

     append: true 

}); 

 

// Serve static files 

app.use(express.static('.')); 

 

// Handle form submission 

app.post('/submit', (req, res) => { 

    const { name, email, phone, message, query } = req.body; 

    csvWriter.writeRecords([{ name, email, phone, message, query }]) 

        .then(() => { 

            res.send('Form data saved to CSV file.'); 

        }); 

}); 

 

app.listen(port, () => { 

    console.log(`Server running at http://localhost:${port}/`); 

}); 